<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Informasi Acara</title>
</head>
<body>
    <h1>Informasi Acara</h1>
    <p>Tanggal dan Waktu: [Tanggal dan Waktu]</p>
    <p>Lokasi: [Lokasi Lengkap]</p>
    <p>Tema: [Tema]</p>
    <p>Dress Code: [Dress Code]</p>
    <a href="registration.php" class="button">Daftar Sekarang</a>
</body>
</html>