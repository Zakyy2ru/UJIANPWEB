<?php
// session_start();

// // Mengatur valid_code menjadi true
// $_SESSION['valid_code'] = true;
// $_SESSION['valid_admin'] = true;

// // Mengarahkan ke halaman pendaftaran
// header("Location: ../public/registration-view.php");
// exit();
?>
